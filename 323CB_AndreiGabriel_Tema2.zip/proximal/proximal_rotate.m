
function R = proximal_rotate(I, rotation_angle)
    % =========================================================================
    % Roteste imaginea alb-negru I de dimensiune m x n cu unghiul rotation_angle,
    % aplic�nd Interpolare Proximala.
    % rotation_angle este exprimat �n radiani.
    % =========================================================================
    [m n nr_colors] = size(I);
    
    I = double(I);

    if nr_colors > 1
        R = -1;
        return
    endif

    % Obs:
    % Atunci c�nd se aplica o scalare, punctul (0, 0) al imaginii nu se va deplasa.
    % �n Octave, pixelii imaginilor sunt indexati de la 1 la n.
    % Daca se lucreaza �n indici de la 1 la n si se inmultesc x si y cu s_x respectiv s_y,
    % atunci originea imaginii se va deplasa de la (1, 1) la (sx, sy)!
    % De aceea, trebuie lucrat cu indici �n intervalul [0, n - 1].

    % TODO: Calculeaza cosinus si sinus de rotation_angle.
    cosO = cos(rotation_angle);
    sinO = sin(rotation_angle);
    
    % TODO: initializeaza matricea finala
    R = zeros(0);
    
    % TODO: calculeaza matricea de transformare
    T_rot = [cosO -sinO; sinO cosO];
    
    % TODO: Inverseaza matricea de transformare.
    T_rot_inv = inv(T_rot);
    % Se parcurge fiecare pixel din imagine.
    for y = 0 : m - 1
        for x = 0 : n - 1
            % TODO: aplica transformarea inversa asupra (x, y) si calculeaza
            % x_p si y_p din spatiul imaginii initiale
            aux = T_rot_inv * [x; y];
            x_p = aux(1, 1);
            y_p = aux(2, 1);
            % Trece (xp, yp) din sistemul de coordonate de la 0 la n - 1 in
            % sistemul de coordonate de la 1 la n pentru a aplica interpolarea
            xp = x_p + 1;
            yp = y_p + 1;
            % TODO: Daca xp sau yp se afla �n exteriorul imaginii,
            % se pune un pixel negru si se trece mai departe.
             if(xp > n || yp > m || xp < 1 || yp < 1)
                R(y+1,x+1) = 0;
                continue;
             endif
            % TODO: Afla punctele ce �nconjoara(xp, yp).
            if(floor(xp) == n)
              x1 = floor(xp) - 1;
              x2 = n;%round(xp + 1);
            else
              x1 = floor(xp);
              x2 = x1 + 1;
            endif
      
            if(floor(yp) == m)
              y1 = floor(yp) - 1;
              y2 = m;
            else
              y1 = floor(yp);
              y2 = y1 + 1;
            endif
            
            % TODO: Calculeaza coeficientii de interpolare notati cu a
            % Obs: Se poate folosi o functie auxiliara �n care sau se calculeze coeficientii,
            % conform formulei.
            
            a = proximal_coef(I, x1, y1, x2, y2);
            
            point = a(1) + a(2)*xp + a(3)*yp + a(4)*yp*xp;
            
            % TODO: Calculeaza valoarea interpolata a pixelului (x, y).
            R(y+1, x+1) = point;
        endfor
    endfor

    % TODO: Transforma matricea rezultata �n uint8 pentru a fi o imagine valida.
     R = uint8(R);
endfunction
