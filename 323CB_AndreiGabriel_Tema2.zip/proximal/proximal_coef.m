function a = proximal_coef(f, x1, y1, x2, y2)
    % =========================================================================
    % Calculeaza coeficientii a pentru Interpolarea Proximala intre punctele
    % (x1, y1), (x1, y2), (x2, y1) si (x2, y2).
    % =========================================================================
    
    % TODO: calculeaza matricea A
    A = [1 x1 y1 x1*y1; 1 x1 y2 x1*y2; 1 x2 y1 x2*y1; 1 x2 y2 x2*y2];
    % TODO: calculeaza vectorul b    
    A11 = f(y1, x1);
    A12 = f(y2, x1);
    A21 = f(y1, x2);
    A22 = f(y2, x2);
    % TODO: calculeaza coeficientii
    a = inv(A) * [A11 A12 A21 A22]';
    
endfunction