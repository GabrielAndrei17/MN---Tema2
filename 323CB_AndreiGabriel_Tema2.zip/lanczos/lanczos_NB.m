function out = lanczoz_NB(A, V, W, m)
  [n, p] = size(V);
  Wt = W';
  
  [T, B] = QR(Wt*V);
  
  V1 = V*inv(B);
  W1 = W*T;
  V2 = A * V1;
  W2 = (A') * W1;
  
  for j = 1 : m
    a(j) = Wt(j) * Vn(j+1);
    Vn(j+1) = Vn(j+1) - V(j) * a(j);
    Wn(j+1) = Wn(j+1) - W(j) * (a(j)');
    
    [V(j+1), B(j+1)] = QR(Vn(j+1));
    [q r] = QR(Wn(j+1));
    
    W(j+1) = q;
    T(j+1) = r';
  endfor
    
endfunction
