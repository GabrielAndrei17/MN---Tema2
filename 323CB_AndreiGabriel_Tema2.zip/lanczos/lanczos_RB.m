function [Vm, Wm] = lanczos_RB(A, B, C)

  [n, n] = size(A);
  [n, p] = size(B);
  
  V = zeros(k,m+1);
  if (nargin == 2)
    V(:,2) = rand(k,1);
  else
    V(:,2)=  0.5*ones(k,1);
  endif
  V(:,2)=V(:,2)/norm(V(:,2),2);
  beta(2)=0;

  

endfunction